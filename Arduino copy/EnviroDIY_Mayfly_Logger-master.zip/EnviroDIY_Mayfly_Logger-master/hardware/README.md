Mayfly Logger
==============

Initial Readme file