Workshop Sketch 2: Button
==============

Turns on and off a light emitting diode(LED) connected to digital pin 8, when pressing the Mayfly push button.

###Basic code elements, Lesson 2:

* Flow Control
  * if... else

### Interactive Exercise

* Serial Monitor
  * Click on Serial Monitor button to open a separate window
  * If you see strange characters, change the baud rate to 57600, in the selector at the bottom of the Serial Monitor window.
* When you push the button, that can be considered another type of sensor for the Mayfly!
